// Lab 7 – Form & Xác thực
// Sinh viên: Đặng Nhật Huy - MSSV: 26A4041188
// File: student_info.dart – Thông tin sinh viên (yêu cầu: Bổ sung tên trong File Code)

class StudentInfo {
  static const String fullName = 'Đặng Nhật Huy';
  static const String studentId = '26A4041188';
  static const String labName = 'Lab 7 – Form & Xác thực';
  static const String className = 'Flutter Practice';

  static String get displayName => '$fullName - $studentId';
}
