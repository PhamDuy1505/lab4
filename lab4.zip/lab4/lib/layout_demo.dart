import 'package:flutter/material.dart';

class LayoutDemo extends StatelessWidget {
  const LayoutDemo({super.key});

  // Danh sách dữ liệu mẫu các bộ phim
  final List<Map<String, String>> movies = const [
    {'title': 'Avatar', 'subtitle': 'Sample description'},
    {'title': 'Inception', 'subtitle': 'Sample description'},
    {'title': 'Interstellar', 'subtitle': 'Sample description'},
    {'title': 'Joker', 'subtitle': 'Sample description'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Exercise 3 – Layout Demo'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0), // Padding đồng nhất 16px cho toàn màn hình
        child: Column(
          children: [
            // Tiêu đề phần (Section header)
            const Text(
              'Now Playing',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16), // Khoảng cách giữa tiêu đề và danh sách

            // Danh sách sử dụng ListView.builder bọc trong Expanded
            Expanded(
              child: ListView.builder(
                itemCount: movies.length,
                itemBuilder: (context, index) {
                  final movie = movies[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12.0), // Spacing giữa các Card
                    elevation: 1,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16.0,
                        vertical: 8.0,
                      ),
                      leading: CircleAvatar(
                        backgroundColor: Colors.indigo.shade100,
                        child: Text(
                          movie['title']![0], // Chữ cái đầu tiên của tên phim
                          style: const TextStyle(
                            color: Colors.indigo,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      title: Text(
                        movie['title']!,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      subtitle: Text(movie['subtitle']!),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}