import 'package:flutter/material.dart';
import 'common_ui_fixes_demo.dart'; // Import Ex 5

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Lab 4 Demo',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.deepPurple,
      ),
      home: const CommonUIFixesDemo(), // Hiển thị Exercise 5
    );
  }
}