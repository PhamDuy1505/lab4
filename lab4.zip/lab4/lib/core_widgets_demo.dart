import 'package:flutter/material.dart';

class CoreWidgetsDemo extends StatelessWidget {
  const CoreWidgetsDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Thanh tiêu đề App Bar
      appBar: AppBar(
        title: const Text('Exercise 1 – Core Widgets'),
      ),
      // Thân bài viết sử dụng SingleChildScrollView để tránh rủi ro tràn màn hình
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // 1. Headline Text
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Welcome to Flutter UI',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // 2. Icon từ Material Icons
            const Icon(
              Icons.movie,
              size: 80,
              color: Colors.blue,
            ),
            const SizedBox(height: 20),

            // 3. Image.network (Ảnh lấy từ đường dẫn URL)
            ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: Image.network(
                'https://picsum.photos/400/200', // Đường dẫn hình ảnh mẫu
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return const Text('Không thể tải hình ảnh');
                },
              ),
            ),
            const SizedBox(height: 20),

            // 4. Card chứa ListTile bên trong
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: const ListTile(
                leading: Icon(Icons.star, color: Colors.amber),
                title: Text(
                  'Movie Item',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text('This is a sample ListTile inside a Card.'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}