import 'package:flutter/material.dart';

class InputControlsDemo extends StatefulWidget {
  const InputControlsDemo({super.key});

  @override
  State<InputControlsDemo> createState() => _InputControlsDemoState();
}

class _InputControlsDemoState extends State<InputControlsDemo> {
  // 1. Quản lý giá trị cho Slider
  double _ratingValue = 50.0;

  // 2. Quản lý giá trị cho Switch
  bool _isMovieActive = false;

  // 3. Quản lý giá trị cho RadioListTile
  String? _selectedGenre = 'None';

  // 4. Quản lý giá trị cho DatePicker
  DateTime? _selectedDate;

  // Hàm mở DatePicker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Exercise 2 – Input Controls'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- SECTION 1: SLIDER ---
            const Text(
              'Rating (Slider)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Slider(
              value: _ratingValue,
              min: 0,
              max: 100,
              divisions: 100,
              label: _ratingValue.round().toString(),
              onChanged: (double value) {
                setState(() {
                  _ratingValue = value;
                });
              },
            ),
            Text('Current value: ${_ratingValue.round()}'),
            const SizedBox(height: 24),

            // --- SECTION 2: SWITCH ---
            const Text(
              'Active (Switch)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SwitchListTile(
              title: const Text('Is movie active?'),
              value: _isMovieActive,
              onChanged: (bool value) {
                setState(() {
                  _isMovieActive = value;
                });
              },
            ),
            const SizedBox(height: 16),

            // --- SECTION 3: RADIO LIST TILE ---
            const Text(
              'Genre (RadioListTile)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            RadioListTile<String>(
              title: const Text('Action'),
              value: 'Action',
              groupValue: _selectedGenre,
              onChanged: (String? value) {
                setState(() {
                  _selectedGenre = value;
                });
              },
            ),
            RadioListTile<String>(
              title: const Text('Comedy'),
              value: 'Comedy',
              groupValue: _selectedGenre,
              onChanged: (String? value) {
                setState(() {
                  _selectedGenre = value;
                });
              },
            ),
            Text('Selected genre: ${_selectedGenre ?? 'None'}'),
            const SizedBox(height: 24),

            // --- SECTION 4: DATE PICKER ---
            Center(
              child: Column(
                children: [
                  OutlinedButton(
                    onPressed: () => _selectDate(context),
                    child: const Text('Open Date Picker'),
                  ),
                  if (_selectedDate != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Selected Date: ${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}