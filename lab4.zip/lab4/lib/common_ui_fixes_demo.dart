import 'package:flutter/material.dart';

class CommonUIFixesDemo extends StatefulWidget {
  const CommonUIFixesDemo({super.key});

  @override
  State<CommonUIFixesDemo> createState() => _CommonUIFixesDemoState();
}

class _CommonUIFixesDemoState extends State<CommonUIFixesDemo> {
  DateTime? _selectedDate;
  int _counter = 0;

  // Fix 4: Gọi showDatePicker từ Valid BuildContext
  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );

    // Fix 3: Cập nhật trạng thái giao diện bằng setState()
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _incrementCounter() {
    // Fix 3: Bắt buộc dùng setState() để Flutter render lại giá trị _counter
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Exercise 5 – Common UI Fixes'),
      ),
      // Fix 2: Dùng SingleChildScrollView bọc ngoài hoặc tránh overflow cho màn hình nhỏ
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Correct ListView inside Column using Expanded',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),

            // Fix 1: Bọc ListView trong Expanded để tránh lỗi unbounded height
            Expanded(
              child: ListView(
                children: const [
                  ListTile(
                    leading: Icon(Icons.movie),
                    title: Text('Movie A'),
                  ),
                  ListTile(
                    leading: Icon(Icons.movie),
                    title: Text('Movie B'),
                  ),
                  ListTile(
                    leading: Icon(Icons.movie),
                    title: Text('Movie C'),
                  ),
                  ListTile(
                    leading: Icon(Icons.movie),
                    title: Text('Movie D'),
                  ),
                ],
              ),
            ),

            const Divider(),

            // Demo Fix 3 & 4
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () => _pickDate(context),
                  child: const Text('Pick Date'),
                ),
                Text(
                  _selectedDate == null
                      ? 'No date'
                      : '${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}',
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: _incrementCounter,
                  child: const Text('Increment Counter'),
                ),
                Text('Counter: $_counter'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}